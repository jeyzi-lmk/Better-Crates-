<?php

namespace CreatesCore;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;
use pocketmine\item\ItemFactory;
use pocketmine\Server;
use pocketmine\world\particle\FlameParticle;
use pocketmine\block\BlockFactory;
use pocketmine\math\Vector3;
use pocketmine\entity\Location;
use pocketmine\entity\object\ItemEntity;
use pocketmine\item\Item;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\inventory\Inventory;
use pocketmine\inventory\SimpleInventory;
use pocketmine\inventory\InventoryType;
use pocketmine\inventory\transaction\InventoryTransaction;
use pocketmine\world\sound\AnvilUseSound;

class Main extends PluginBase implements Listener {

    private static Main $instance;
    private array $placedCrates = [];
    private array $crateData = [];

    public function onEnable(): void {
        self::$instance = $this;
        $this->saveDefaultConfig();
        $this->crateData = $this->getConfig()->get("crates", []);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info(TF::GREEN . "CreatesCore activado.");
    }

    public static function getInstance(): Main {
        return self::$instance;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player && $label === "create") {
            $sender->sendMessage("Usa esto en el juego.");
            return true;
        }

        if (!isset($args[0])) {
            $sender->sendMessage("/create <give|place|keyall> <tipo> [jugador]");
            return true;
        }

        switch ($args[0]) {
            case "give":
                if (empty($args[1])) {
                    $sender->sendMessage("§cUsa: /create give <tipo> [jugador]");
                    break;
                }
                $player = isset($args[2]) ? Server::getInstance()->getPlayerExact($args[2]) : $sender;
                if (!$player) {
                    $sender->sendMessage("§cJugador no encontrado.");
                    break;
                }
                $item = ItemFactory::getInstance()->get(131, 0, 1)->setCustomName("§r§6Llave " . ucfirst($args[1]));
                $item->getNamedTag()->setString("crate", strtolower($args[1]));
                $player->getInventory()->addItem($item);
                $player->sendMessage("§aHas recibido una llave {$args[1]}.");
                break;

            case "place":
                if (empty($args[1])) {
                    $sender->sendMessage("§cUsa: /create place <tipo>");
                    break;
                }
                $pos = $sender->getPosition()->floor()->add(0, 0, 1);
                $world = $sender->getWorld();
                $this->placedCrates[$pos->__toString()] = strtolower($args[1]);

                $world->setBlock($pos, BlockFactory::getInstance()->get(54, 0));
                $world->addParticle($pos->add(0.5, 1, 0.5), new FlameParticle());

                $item = ItemFactory::getInstance()->get(264);
                $entity = new ItemEntity(Location::fromObject($pos->add(0.5, 1.2, 0.5), $world, 0, 0), $item);
                $entity->setNameTag("§b" . ucfirst($args[1]) . " Crate");
                $entity->setNameTagAlwaysVisible();
                $entity->spawnToAll();

                $sender->sendMessage("§aCrate {$args[1]} colocada.");
                break;

            case "keyall":
                if (empty($args[1])) {
                    $sender->sendMessage("§cUsa: /create keyall <tipo>");
                    break;
                }
                foreach (Server::getInstance()->getOnlinePlayers() as $p) {
                    $item = ItemFactory::getInstance()->get(131, 0, 1)->setCustomName("§r§6Llave " . ucfirst($args[1]));
                    $item->getNamedTag()->setString("crate", strtolower($args[1]));
                    $p->getInventory()->addItem($item);
                    $p->sendMessage("§aHas recibido una llave {$args[1]}.");
                }
                $sender->sendMessage("§aKeyAll enviado.");
                break;
        }
        return true;
    }

    public function onPlayerItemUse(PlayerItemUseEvent $event): void {
        $item = $event->getItem();
        $player = $event->getPlayer();
        $tag = $item->getNamedTag();
        if ($tag->getTag("crate") !== null) {
            $type = $tag->getString("crate");
            $data = $this->crateData[$type] ?? null;
            if ($data === null) {
                $player->sendMessage("§cEsta crate no está configurada.");
                return;
            }
            $inv = new SimpleInventory(27);
            $inv->setName("§l§6" . strtoupper($type) . " Crate");

            foreach ($data["rewards"] as $index => $reward) {
                $slot = $index;
                $item = StringToItemParser::getInstance()->parse($reward["item"]);
                $item->setCustomName($reward["name"]);
                $inv->setItem($slot, $item);
            }

            $player->removeCurrentWindow();
            $player->sendMessage("§aAbriendo crate...");
            $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
            $player->sendDelayedWindow($inv, 20);
        }
    }
}
